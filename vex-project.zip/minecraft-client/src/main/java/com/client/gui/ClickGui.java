package com.client.gui;

import com.client.ClientMain;
import com.client.module.Module;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;

import java.util.ArrayList;
import java.util.List;

public class ClickGui extends Screen {
    private final List<CategoryPanel> panels = new ArrayList<>();
    private ModulePanel activeModulePanel = null;
    private boolean dragging = false;
    private double dragOffsetX, dragOffsetY;
    private CategoryPanel dragTarget = null;

    // Modern color scheme
    public static final int BG_COLOR = 0xE0101018;
    public static final int PANEL_COLOR = 0xF01A1A2E;
    public static final int PANEL_HEADER = 0xFF2D2D44;
    public static final int MODULE_COLOR = 0xFF252540;
    public static final int MODULE_HOVER = 0xFF353560;
    public static final int ACCENT = 0xFF7C5CFC;
    public static final int ACCENT_HOVER = 0xFF9B7FFF;
    public static final int TEXT_PRIMARY = 0xFFE0E0F0;
    public static final int TEXT_SECONDARY = 0xFF9090B0;
    public static final int TOGGLE_ON = 0xFF7C5CFC;
    public static final int TOGGLE_OFF = 0xFF404060;
    public static final int DIVIDER = 0xFF303050;

    public ClickGui() {
        super(Text.of("Anchor Client"));
    }

    @Override
    protected void init() {
        panels.clear();
        int x = 20;
        for (Module.Category cat : Module.Category.values()) {
            panels.add(new CategoryPanel(cat, x, 20));
            x += 160;
        }
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        // Dark overlay background
        context.fill(0, 0, this.width, this.height, 0xC0080810);

        // Render panels
        for (CategoryPanel panel : panels) {
            panel.render(context, mouseX, mouseY);
        }

        // Render active module settings overlay
        if (activeModulePanel != null) {
            activeModulePanel.render(context, mouseX, mouseY);
        }
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        // Check module settings panel first
        if (activeModulePanel != null) {
            if (activeModulePanel.mouseClicked(mouseX, mouseY, button)) {
                return true;
            }
            // Click outside closes settings
            if (!activeModulePanel.isMouseOver(mouseX, mouseY)) {
                activeModulePanel = null;
                return true;
            }
        }

        for (CategoryPanel panel : panels) {
            if (panel.isMouseOverHeader(mouseX, mouseY) && button == 0) {
                dragging = true;
                dragTarget = panel;
                dragOffsetX = mouseX - panel.getX();
                dragOffsetY = mouseY - panel.getY();
                return true;
            }
            Module clickedModule = panel.getModuleAt(mouseX, mouseY);
            if (clickedModule != null) {
                if (button == 0) {
                    clickedModule.toggle();
                    return true;
                } else if (button == 1) {
                    activeModulePanel = new ModulePanel(clickedModule,
                            (int) mouseX, (int) mouseY);
                    return true;
                }
            }
        }
        return super.mouseClicked(mouseX, mouseY, button);
    }

    @Override
    public boolean mouseReleased(double mouseX, double mouseY, int button) {
        dragging = false;
        dragTarget = null;
        return super.mouseReleased(mouseX, mouseY, button);
    }

    @Override
    public boolean mouseDragged(double mouseX, double mouseY, int button,
                                 double deltaX, double deltaY) {
        if (dragging && dragTarget != null) {
            dragTarget.setPosition((int) (mouseX - dragOffsetX),
                    (int) (mouseY - dragOffsetY));
            return true;
        }
        return super.mouseDragged(mouseX, mouseY, button, deltaX, deltaY);
    }

    @Override
    public boolean shouldPause() {
        return false;
    }

    // Inner class for category panels
    public class CategoryPanel {
        private final Module.Category category;
        private int x, y;
        private final int width = 140;
        private final int headerHeight = 28;
        private boolean expanded = true;

        public CategoryPanel(Module.Category category, int x, int y) {
            this.category = category;
            this.x = x;
            this.y = y;
        }

        public void render(DrawContext ctx, int mouseX, int mouseY) {
            // Panel background
            ctx.fill(x, y, x + width, y + getHeight(), PANEL_COLOR);

            // Header with accent line
            ctx.fill(x, y, x + width, y + headerHeight, PANEL_HEADER);
            ctx.fill(x, y, x + 3, y + headerHeight, ACCENT);

            // Category name
            ctx.drawTextWithShadow(textRenderer, category.getName(),
                    x + 10, y + 9, TEXT_PRIMARY);

            // Expand indicator
            String indicator = expanded ? "−" : "+";
            ctx.drawTextWithShadow(textRenderer, indicator,
                    x + width - 14, y + 9, TEXT_SECONDARY);

            if (!expanded) return;

            // Module list
            int yOffset = y + headerHeight + 4;
            List<Module> modules = ClientMain.getInstance()
                    .getModuleManager().getModulesByCategory(category);
            for (Module module : modules) {
                boolean hover = mouseX >= x + 4 && mouseX <= x + width - 4
                        && mouseY >= yOffset && mouseY <= yOffset + 22;

                // Module background
                int bgColor = hover ? MODULE_HOVER : MODULE_COLOR;
                ctx.fill(x + 4, yOffset, x + width - 4, yOffset + 22, bgColor);

                // Toggle indicator (small dot)
                int dotColor = module.isEnabled() ? TOGGLE_ON : TOGGLE_OFF;
                ctx.fill(x + 8, yOffset + 8, x + 14, yOffset + 14, dotColor);

                // Module name
                ctx.drawTextWithShadow(textRenderer, module.getName(),
                        x + 20, yOffset + 6, module.isEnabled() ? ACCENT : TEXT_PRIMARY);

                // Right-click hint
                ctx.drawTextWithShadow(textRenderer, "⋮",
                        x + width - 16, yOffset + 6, TEXT_SECONDARY);

                yOffset += 24;
            }
        }

        public int getHeight() {
            if (!expanded) return headerHeight;
            int count = ClientMain.getInstance()
                    .getModuleManager().getModulesByCategory(category).size();
            return headerHeight + 8 + count * 24;
        }

        public boolean isMouseOverHeader(double mx, double my) {
            return mx >= x && mx <= x + width && my >= y && my <= y + headerHeight;
        }

        public boolean isMouseOver(double mx, double my) {
            return mx >= x && mx <= x + width && my >= y && my + getHeight() >= y;
        }

        public Module getModuleAt(double mx, double my) {
            int yOffset = y + headerHeight + 4;
            List<Module> modules = ClientMain.getInstance()
                    .getModuleManager().getModulesByCategory(category);
            for (Module module : modules) {
                if (mx >= x + 4 && mx <= x + width - 4
                        && my >= yOffset && my <= yOffset + 22) {
                    return module;
                }
                yOffset += 24;
            }
            return null;
        }

        public int getX() { return x; }
        public int getY() { return y; }
        public void setPosition(int x, int y) { this.x = x; this.y = y; }
    }
}
