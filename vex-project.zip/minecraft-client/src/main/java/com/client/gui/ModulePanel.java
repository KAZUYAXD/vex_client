package com.client.gui;

import com.client.module.Module;
import com.client.module.combat.AnchorMacro;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.Element;

import java.util.ArrayList;
import java.util.List;

public class ModulePanel implements Element {
    private final Module module;
    private int x, y;
    private final int width = 200;
    private int height;
    private final List<SettingWidget> widgets = new ArrayList<>();
    private boolean listeningForKey = false;

    public ModulePanel(Module module, int x, int y) {
        this.module = module;
        this.x = Math.min(x, 800);
        this.y = Math.min(y, 400);
        buildWidgets();
    }

    private void buildWidgets() {
        widgets.clear();
        int wy = y + 36;

        if (module instanceof AnchorMacro anchor) {
            // Keybind setting
            widgets.add(new SettingWidget("Keybind", SettingWidget.Type.KEYBIND, wy) {
                @Override
                public String getValue() {
                    int kb = anchor.getKeyBind();
                    return kb >= 0 ? org.lwjgl.glfw.GLFW.glfwGetKeyName(kb, 0) : "NONE";
                }
                @Override
                public void onClick() {
                    listeningForKey = !listeningForKey;
                }
            });
            wy += 30;

            // Min delay
            widgets.add(new SettingWidget("Min Delay", SettingWidget.Type.SLIDER, wy) {
                @Override
                public String getValue() {
                    return String.format("%.1f", anchor.getMinDelay());
                }
                @Override
                public float getSliderProgress() {
                    return (anchor.getMinDelay() - 0.1f) / 9.9f;
                }
                @Override
                public void onSlider(double mx) {
                    float progress = (float) Math.max(0, Math.min(1,
                            (mx - (x + 100)) / 80));
                    anchor.setMinDelay(0.1f + progress * 9.9f);
                }
            });
            wy += 30;

            // Max delay
            widgets.add(new SettingWidget("Max Delay", SettingWidget.Type.SLIDER, wy) {
                @Override
                public String getValue() {
                    return String.format("%.1f", anchor.getMaxDelay());
                }
                @Override
                public float getSliderProgress() {
                    return (anchor.getMaxDelay() - 0.1f) / 9.9f;
                }
                @Override
                public void onSlider(double mx) {
                    float progress = (float) Math.max(0, Math.min(1,
                            (mx - (x + 100)) / 80));
                    anchor.setMaxDelay(0.1f + progress * 9.9f);
                }
            });
            wy += 30;

            // Style toggle
            widgets.add(new SettingWidget("Style", SettingWidget.Type.MODE, wy) {
                @Override
                public String getValue() {
                    return anchor.isSilent() ? "Silent" : "Aim";
                }
                @Override
                public void onClick() {
                    anchor.setSilent(!anchor.isSilent());
                }
            });
            wy += 30;

            // Pearl After toggle
            widgets.add(new SettingWidget("Pearl After", SettingWidget.Type.TOGGLE, wy) {
                @Override
                public String getValue() {
                    return anchor.isPearlAfter() ? "ON" : "OFF";
                }
                @Override
                public boolean isEnabled() {
                    return anchor.isPearlAfter();
                }
                @Override
                public void onClick() {
                    anchor.setPearlAfter(!anchor.isPearlAfter());
                }
            });
            wy += 30;
        }

        height = wy - y + 8;
    }

    public void render(DrawContext ctx, int mouseX, int mouseY) {
        // Panel background with rounded feel
        ctx.fill(x, y, x + width, y + height, ClickGui.PANEL_COLOR);
        ctx.fill(x, y, x + width, y + 30, ClickGui.PANEL_HEADER);
        ctx.fill(x, y, x + 3, y + height, ClickGui.ACCENT);

        // Title
        ctx.drawTextWithShadow(ctx.getGui().getTextRenderer(),
                module.getName() + " Settings",
                x + 10, y + 9, ClickGui.TEXT_PRIMARY);

        // Close hint
        ctx.drawTextWithShadow(ctx.getGui().getTextRenderer(),
                "×", x + width - 18, y + 9, ClickGui.TEXT_SECONDARY);

        // Keybind listening indicator
        if (listeningForKey) {
            ctx.fill(x + 10, y + 32, x + width - 10, y + 58, ClickGui.MODULE_HOVER);
            ctx.drawCenteredTextWithShadow(ctx.getGui().getTextRenderer(),
                    "Press any key...", x + width / 2, y + 40, ClickGui.ACCENT);
        }

        // Render widgets
        for (SettingWidget widget : widgets) {
            widget.render(ctx, x, mouseX, mouseY);
        }
    }

    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        if (mouseX < x || mouseX > x + width || mouseY < y || mouseY > y + height) {
            return false;
        }

        for (SettingWidget widget : widgets) {
            if (widget.isMouseOver(mouseX, mouseY)) {
                widget.onClick();
                return true;
            }
        }
        return true;
    }

    public boolean isMouseOver(double mx, double my) {
        return mx >= x && mx <= x + width && my >= y && my <= y + height;
    }

    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (listeningForKey) {
            if (module instanceof AnchorMacro anchor) {
                anchor.setKeyBind(keyCode);
            }
            listeningForKey = false;
            return true;
        }
        return false;
    }

    public abstract static class SettingWidget {
        public enum Type { KEYBIND, SLIDER, MODE, TOGGLE }

        private final String name;
        private final Type type;
        private final int yOffset;

        public SettingWidget(String name, Type type, int yOffset) {
            this.name = name;
            this.type = type;
            this.yOffset = yOffset;
        }

        public abstract String getValue();
        public void onClick() {}
        public void onSlider(double mx) {}
        public float getSliderProgress() { return 0; }
        public boolean isEnabled() { return false; }

        public void render(DrawContext ctx, int panelX, int mouseX, int mouseY) {
            int wx = panelX + 8;
            int wy = yOffset;
            int ww = 184;

            boolean hover = mouseX >= wx && mouseX <= wx + ww
                    && mouseY >= wy && mouseY <= wy + 26;
            int bg = hover ? ClickGui.MODULE_HOVER : ClickGui.MODULE_COLOR;
            ctx.fill(wx, wy, wx + ww, wy + 26, bg);

            // Name
            ctx.drawTextWithShadow(ctx.getGui().getTextRenderer(),
                    name, wx + 6, wy + 7, ClickGui.TEXT_PRIMARY);

            // Value display
            String val = getValue();
            int valWidth = ctx.getGui().getTextRenderer().getWidth(val);

            switch (type) {
                case TOGGLE -> {
                    int dotX = wx + ww - 20;
                    int dotColor = isEnabled() ? ClickGui.TOGGLE_ON : ClickGui.TOGGLE_OFF;
                    ctx.fill(dotX, wy + 8, dotX + 12, wy + 18, dotColor);
                }
                case MODE -> {
                    ctx.drawTextWithShadow(ctx.getGui().getTextRenderer(),
                            val, wx + ww - valWidth - 6, wy + 7, ClickGui.ACCENT);
                }
                case SLIDER -> {
                    int barX = wx + 90;
                    int barW = ww - 100;
                    ctx.fill(barX, wy + 12, barX + barW, wy + 14, ClickGui.TOGGLE_OFF);
                    int fillW = (int) (barW * getSliderProgress());
                    ctx.fill(barX, wy + 12, barX + fillW, wy + 14, ClickGui.ACCENT);
                    ctx.drawTextWithShadow(ctx.getGui().getTextRenderer(),
                            val, barX + barW + 4, wy + 7, ClickGui.TEXT_SECONDARY);
                }
                case KEYBIND -> {
                    ctx.drawTextWithShadow(ctx.getGui().getTextRenderer(),
                            "[" + val + "]", wx + ww - valWidth - 14, wy + 7,
                            listeningForKey ? ClickGui.ACCENT : ClickGui.TEXT_SECONDARY);
                }
            }
        }

        public boolean isMouseOver(double mx, double my) {
            return mx >= x + 8 && mx <= x + 192
                    && my >= yOffset && my <= yOffset + 26;
        }
    }
}
