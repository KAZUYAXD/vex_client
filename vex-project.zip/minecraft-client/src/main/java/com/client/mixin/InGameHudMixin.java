package com.client.mixin;

import com.client.ClientMain;
import com.client.module.Module;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.hud.InGameHud;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(InGameHud.class)
public class InGameHudMixin {
    @Inject(method = "render", at = @At("TAIL"))
    private void onRender(DrawContext context, float tickDelta, CallbackInfo ci) {
        if (ClientMain.getInstance() == null) return;

        // Watermark
        context.fill(4, 4, 100, 18, 0xC0101018);
        context.drawTextWithShadow(
                net.minecraft.client.MinecraftClient.getInstance().textRenderer,
                "Anchor Client v1.0", 8, 6, 0xFF7C5CFC);

        // Active modules list
        int y = 24;
        for (Module module : ClientMain.getInstance().getModuleManager().getModules()) {
            if (module.isEnabled()) {
                int w = net.minecraft.client.MinecraftClient.getInstance()
                        .textRenderer.getWidth("[ " + module.getName() + " ]");
                context.fill(4, y, w + 12, y + 14, 0xC0101018);
                context.drawTextWithShadow(
                        net.minecraft.client.MinecraftClient.getInstance().textRenderer,
                        "[ " + module.getName() + " ]", 8, y + 2, 0xFF7C5CFC);
                y += 16;
            }
        }
    }
}
