package com.client.mixin;

import com.client.ClientMain;
import com.client.module.Module;
import net.minecraft.client.MinecraftClient;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(MinecraftClient.class)
public class MinecraftClientMixin {
    @Inject(method = "tick", at = @At("TAIL"))
    private void onTick(CallbackInfo ci) {
        // Module keybind handling
        MinecraftClient client = (MinecraftClient) (Object) this;
        if (client.currentScreen == null && ClientMain.getInstance() != null) {
            for (Module module : ClientMain.getInstance().getModuleManager().getModules()) {
                if (module.getKeyBind() >= 0) {
                    // Keybind handled in Module.onTick via GLFW polling
                }
            }
        }
    }
}
