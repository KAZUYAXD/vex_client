package com.client;

import com.client.gui.ClickGui;
import com.client.module.ModuleManager;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import org.lwjgl.glfw.GLFW;

public class ClientMain implements ClientModInitializer {
    private static ClientMain INSTANCE;
    private ModuleManager moduleManager;
    private ClickGui clickGui;
    private KeyBinding openGuiKey;

    @Override
    public void onInitializeClient() {
        INSTANCE = this;
        moduleManager = new ModuleManager();
        clickGui = new ClickGui();

        openGuiKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "Open GUI", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_RIGHT_SHIFT, "Anchor Client"
        ));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (openGuiKey.wasPressed()) {
                if (client.currentScreen == null) {
                    client.setScreen(clickGui);
                }
            }
            moduleManager.onTick();
        });
    }

    public static ClientMain getInstance() {
        return INSTANCE;
    }

    public ModuleManager getModuleManager() {
        return moduleManager;
    }

    public ClickGui getClickGui() {
        return clickGui;
    }
}
