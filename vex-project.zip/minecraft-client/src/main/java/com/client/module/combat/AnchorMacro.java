package com.client.module.combat;

import com.client.module.Module;
import net.minecraft.block.Blocks;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;

import java.util.Random;

public class AnchorMacro extends Module {
    private int keyBind = -1;
    private float minDelay = 0.1f;
    private float maxDelay = 1.0f;
    private boolean silent = false;
    private boolean pearlAfter = false;

    // State machine
    private enum State { IDLE, PLACE_ANCHOR, CHARGE_ANCHOR, USE_TOTEM, PEARL_DOWN }
    private State state = State.IDLE;
    private long lastActionTime = 0;
    private long currentDelay = 0;
    private int anchorSlot = -1;
    private int totemSlot = -1;
    private int prevTotemSlot = -1;
    private BlockPos anchorPos = null;
    private boolean wasTotemInOffhand = false;
    private final Random random = new Random();

    public AnchorMacro() {
        super("Anchor Macro", "Respawn anchor automation", Category.COMBAT);
    }

    @Override
    public void onTick() {
        if (mc.player == null || mc.world == null) return;

        // Check keybind
        if (keyBind >= 0 && org.lwjgl.glfw.GLFW.glfwGetKey(
                mc.getWindow().getHandle(), keyBind) == 1) {
            if (state == State.IDLE) {
                startMacro();
            }
        }

        // Process state machine
        if (state != State.IDLE) {
            long now = System.currentTimeMillis();
            if (now - lastActionTime >= currentDelay) {
                processState();
            }
        }

        // Detect totem pop and re-equip
        checkTotemPop();
    }

    private void startMacro() {
        // Find respawn anchor in hotbar or inventory
        anchorSlot = findItem(Items.RESPAWN_ANCHOR);
        if (anchorSlot == -1) return;

        totemSlot = findItem(Items.TOTEM_OF_UNDYING);
        if (totemSlot == -1) return;

        // Remember if we had a totem in offhand
        wasTotemInOffhand = mc.player.getOffHandStack().getItem() == Items.TOTEM_OF_UNDYING;
        prevTotemSlot = wasTotemInOffhand ? -2 : totemSlot; // -2 = offhand

        state = State.PLACE_ANCHOR;
        lastActionTime = System.currentTimeMillis();
        currentDelay = getRandomDelay();
    }

    private void processState() {
        switch (state) {
            case PLACE_ANCHOR -> {
                // Switch to anchor slot and place it
                if (anchorSlot >= 0 && anchorSlot < 9) {
                    mc.player.getInventory().selectedSlot = anchorSlot;
                } else if (anchorSlot >= 9) {
                    // Move from inventory to hotbar
                    swapToHotbar(anchorSlot, 0);
                    mc.player.getInventory().selectedSlot = 0;
                }

                // Place anchor on ground
                BlockPos below = mc.player.getBlockPos().down();
                if (silent) {
                    // Silent: place without looking
                    mc.interactionManager.interactBlock(mc.player, Hand.MAIN_HAND,
                            new BlockHitResult(Vec3d.ofCenter(below), Direction.UP, below, false));
                } else {
                    // Aim: look at ground then place
                    lookAtBlock(below);
                    mc.interactionManager.interactBlock(mc.player, Hand.MAIN_HAND,
                            new BlockHitResult(Vec3d.ofCenter(below), Direction.UP, below, false));
                }
                anchorPos = below.up();

                state = State.CHARGE_ANCHOR;
                lastActionTime = System.currentTimeMillis();
                currentDelay = getRandomDelay();
            }

            case CHARGE_ANCHOR -> {
                // Find glowstone in inventory
                int glowSlot = findItem(Items.GLOWSTONE);
                if (glowSlot == -1) {
                    state = State.IDLE;
                    return;
                }

                // Switch to glowstone
                if (glowSlot >= 0 && glowSlot < 9) {
                    mc.player.getInventory().selectedSlot = glowSlot;
                } else {
                    swapToHotbar(glowSlot, 1);
                    mc.player.getInventory().selectedSlot = 1;
                }

                // Right click anchor to charge
                if (anchorPos != null) {
                    if (silent) {
                        mc.interactionManager.interactBlock(mc.player, Hand.MAIN_HAND,
                                new BlockHitResult(Vec3d.ofCenter(anchorPos), Direction.UP, anchorPos, false));
                    } else {
                        lookAtBlock(anchorPos);
                        mc.interactionManager.interactBlock(mc.player, Hand.MAIN_HAND,
                                new BlockHitResult(Vec3d.ofCenter(anchorPos), Direction.UP, anchorPos, false));
                    }
                }

                state = State.USE_TOTEM;
                lastActionTime = System.currentTimeMillis();
                currentDelay = getRandomDelay();
            }

            case USE_TOTEM -> {
                // Find totem and switch to it
                totemSlot = findItem(Items.TOTEM_OF_UNDYING);
                if (totemSlot == -1) {
                    state = State.IDLE;
                    return;
                }

                // Move totem to offhand
                if (totemSlot >= 9) {
                    swapToHotbar(totemSlot, 2);
                    mc.player.getInventory().selectedSlot = 2;
                } else {
                    mc.player.getInventory().selectedSlot = totemSlot;
                }

                // Right click anchor with totem to set spawn
                if (anchorPos != null) {
                    if (silent) {
                        mc.interactionManager.interactBlock(mc.player, Hand.MAIN_HAND,
                                new BlockHitResult(Vec3d.ofCenter(anchorPos), Direction.UP, anchorPos, false));
                    } else {
                        lookAtBlock(anchorPos);
                        mc.interactionManager.interactBlock(mc.player, Hand.MAIN_HAND,
                                new BlockHitResult(Vec3d.ofCenter(anchorPos), Direction.UP, anchorPos, false));
                    }
                }

                // Switch back to previous totem or re-equip
                reEquipTotem();

                if (pearlAfter) {
                    state = State.PEARL_DOWN;
                    lastActionTime = System.currentTimeMillis();
                    currentDelay = getRandomDelay();
                } else {
                    state = State.IDLE;
                }
            }

            case PEARL_DOWN -> {
                // Find ender pearl
                int pearlSlot = findItem(Items.ENDER_PEARL);
                if (pearlSlot == -1) {
                    state = State.IDLE;
                    return;
                }

                // Switch to pearl
                if (pearlSlot >= 0 && pearlSlot < 9) {
                    mc.player.getInventory().selectedSlot = pearlSlot;
                } else {
                    swapToHotbar(pearlSlot, 3);
                    mc.player.getInventory().selectedSlot = 3;
                }

                // Look down and throw pearl into the hole
                if (!silent) {
                    lookDown();
                }
                mc.interactionManager.interactItem(mc.player, Hand.MAIN_HAND);

                state = State.IDLE;
            }
        }
    }

    private void checkTotemPop() {
        if (mc.player == null) return;

        // Check if offhand totem was consumed (popped)
        boolean hasTotemOffhand = mc.player.getOffHandStack().getItem() == Items.TOTEM_OF_UNDYING;
        boolean hasTotemMainhand = mc.player.getMainHandStack().getItem() == Items.TOTEM_OF_UNDYING;

        if (!hasTotemOffhand && wasTotemInOffhand && state == State.IDLE) {
            // Totem popped, find a new one and equip it
            int newTotem = findItem(Items.TOTEM_OF_UNDYING);
            if (newTotem != -1) {
                if (newTotem >= 9) {
                    // Move from inventory to offhand (slot 45 in container)
                    mc.interactionManager.clickSlot(
                            mc.player.playerScreenHandler.syncId,
                            newTotem, 40, SlotActionType.SWAP, mc.player);
                }
            }
            wasTotemInOffhand = false;
        }

        // Update state
        if (hasTotemOffhand) {
            wasTotemInOffhand = true;
        }
    }

    private void reEquipTotem() {
        if (mc.player == null) return;
        int totem = findItem(Items.TOTEM_OF_UNDYING);
        if (totem != -1 && !mc.player.getOffHandStack().getItem().equals(Items.TOTEM_OF_UNDYING)) {
            if (totem >= 9) {
                mc.interactionManager.clickSlot(
                        mc.player.playerScreenHandler.syncId,
                        totem, 40, SlotActionType.SWAP, mc.player);
            }
        }
    }

    private int findItem(net.minecraft.item.Item item) {
        if (mc.player == null) return -1;
        PlayerInventory inv = mc.player.getInventory();

        // Check hotbar first
        for (int i = 0; i < 9; i++) {
            if (inv.getStack(i).getItem() == item) return i;
        }
        // Check rest of inventory
        for (int i = 9; i < inv.size(); i++) {
            if (inv.getStack(i).getItem() == item) return i;
        }
        return -1;
    }

    private void swapToHotbar(int fromSlot, int hotbarSlot) {
        if (mc.player == null || mc.interactionManager == null) return;
        mc.interactionManager.clickSlot(
                mc.player.playerScreenHandler.syncId,
                fromSlot, hotbarSlot, SlotActionType.SWAP, mc.player);
    }

    private void lookAtBlock(BlockPos pos) {
        if (mc.player == null) return;
        Vec3d eyePos = mc.player.getEyePos();
        Vec3d target = Vec3d.ofCenter(pos);
        double dx = target.x - eyePos.x;
        double dy = target.y - eyePos.y;
        double dz = target.z - eyePos.z;
        double dist = Math.sqrt(dx * dx + dz * dz);
        float yaw = (float) Math.toDegrees(Math.atan2(-dx, dz));
        float pitch = (float) Math.toDegrees(Math.atan2(-dy, dist));
        mc.player.setYaw(yaw);
        mc.player.setPitch(pitch);
    }

    private void lookDown() {
        if (mc.player == null) return;
        mc.player.setPitch(90.0f);
    }

    private long getRandomDelay() {
        float delay = minDelay + random.nextFloat() * (maxDelay - minDelay);
        return (long) (delay * 1000);
    }

    // Getters and setters for GUI
    public int getKeyBind() { return keyBind; }
    public void setKeyBind(int keyBind) { this.keyBind = keyBind; }
    public float getMinDelay() { return minDelay; }
    public void setMinDelay(float minDelay) { this.minDelay = Math.max(0.1f, Math.min(minDelay, maxDelay)); }
    public float getMaxDelay() { return maxDelay; }
    public void setMaxDelay(float maxDelay) { this.maxDelay = Math.max(minDelay, Math.min(maxDelay, 10.0f)); }
    public boolean isSilent() { return silent; }
    public void setSilent(boolean silent) { this.silent = silent; }
    public boolean isPearlAfter() { return pearlAfter; }
    public void setPearlAfter(boolean pearlAfter) { this.pearlAfter = pearlAfter; }
}
